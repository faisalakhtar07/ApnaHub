# APNAHUB — Frontend (Phase 1)

Hyperlocal platform for Aurangabad, Bihar. This is **Phase 1** of the build:
project scaffold + the fully designed Home page, using mock data. Auth,
the backend API, and the Business/Jobs/Buy & Sell pages come in later phases.

## Design system

- **Colors**: ink `#14151F`, paper `#F3F5F6`, indigo-900 `#1B1F3B` (brand/dark),
  sindoor `#E4472B` (primary accent/CTA), peacock `#0E7C7B` (trust/verified),
  gold `#D4A017` (secondary accent). See `tailwind.config.js`.
- **Type**: Space Grotesk (display), Inter (body), JetBrains Mono (stamps, prices, labels).
- **Signature motif**: the "stamp" badge (`StampBadge.jsx`) — a rotated, dashed-border
  tag echoing physical shop-bill seals — used for Verified / New / Popular markers only.
- **Dark mode**: class-based (`darkMode: 'class'`), toggled via `ThemeContext`, persisted
  to `localStorage`, defaults to OS preference on first visit.

## Getting started

```bash
npm install
npm run dev
```

Then open the printed local URL (usually http://localhost:5173).

## Project structure

```
src/
  components/
    layout/       Navbar, Footer
    common/       StampBadge, SkeletonCard (shared across future pages)
    home/         All Home page sections
  context/        ThemeContext (dark/light mode)
  data/           mockData.js — shaped to match planned MongoDB schemas
  pages/          Home.jsx (more pages added in later phases)
  App.jsx         Router + layout shell
  main.jsx        Entry point
```

## Next phases

- **Phase 2**: Auth (signup/login/forgot password/email verification) — React forms + Express/JWT backend
- **Phase 3**: Businesses, Jobs, Buy & Sell — full CRUD, Cloudinary uploads, search & filters
- **Phase 4**: User dashboard + Admin dashboard
- **Phase 5**: Wishlist, share, report, WhatsApp/Maps integration, SEO, pagination

Mock data in `src/data/mockData.js` is intentionally shaped like the future
Mongoose schemas, so swapping in real Axios calls later won't require
rewriting component logic — just replacing the data source.
